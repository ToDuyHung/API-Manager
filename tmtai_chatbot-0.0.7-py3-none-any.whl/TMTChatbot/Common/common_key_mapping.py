KEY_MAPPING = {
    "price": "giá",
    "current_price": "giá hiện tại",
    "discount": "giảm giá",
    "original_price": "giá gốc",
    "origin": "xuất xứ",
    "material": "chất liệu"
}
