class StateStatus:
    DONE = "DONE"
    PROCESSING = "PROCESSING"
    PASS = "PASS"
