from enum import Enum


class SentenceTypes(Enum):
    QUESTION = 0
    COMMAND = 1
    NORMAL = 2
